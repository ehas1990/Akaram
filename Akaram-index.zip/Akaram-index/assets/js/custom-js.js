$(document).ready(function() {  
   $(".read-more").click(function(){

$(".list_1").hide();
$(".list_2").show();     
$(".list_3").hide();           
    }); 
    $(".read-more1").click(function(){

        $(".list_1").hide();
        $(".list_3").show();     
        $(".list_2").hide();           
            }); 


    });  
